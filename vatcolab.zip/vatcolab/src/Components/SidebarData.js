

export const SidebarData = [
    {
        title:"Dashboard",
        link:"/"
    },
    {
        title:"Trades",
        link:"/Trades"
    },
    {
        title:"Watchlist",
        link:"/Watchlist"
    },
    {
        title:"Profile",
        link:"/Profile"
    }
    // {
    //     title:"Users",
    //     link:"/Users"
    // },
    // {
    //     title:"Business Info",
    //     link:"/ServiceDetails"
    // },
    
]